# Ushakov AI
AI-powered study assistant prototype with chat, homework help, summaries, test preparation, image generation ideas, and PRO/promo demo.

## Current version
This is a frontend prototype. No real AI API is connected yet.

## Files
- `index.html` — app structure
- `style.css` — design
- `app.js` — demo interactions

## Demo promo codes
- `WELCOME`
- `PRO7`
- `PRO30`

For production, connect a backend and keep API keys server-side.
